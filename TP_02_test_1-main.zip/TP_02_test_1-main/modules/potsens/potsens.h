//=====[#include guards - begin]===============================================

#ifndef _POTSENS_H_
#define _POTSENS_H_

//=====[Declaration of public defines]=========================================

//#define SYSTEM_TIME_INCREMENT_MS   10

//=====[Declaration of public data types]======================================

//=====[Declarations (prototypes) of public functions]=========================

void updateSens(log_t* sens);

//=====[#include guards - end]=================================================

#endif // _POTSENS_H_
