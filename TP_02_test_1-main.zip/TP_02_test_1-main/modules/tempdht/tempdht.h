//=====[#include guards - begin]===============================================
#ifndef _TEMPSENSOR_H_
#define _TEMPSENSOR_H_

#include "eventlog.h"

//=====[Declaration of public defines]=========================================


//=====[Declaration of public data types]======================================

//=====[Declarations (prototypes) of public functions]=========================

void updateSensorDHT(log_t* sensorlog);

//=====[#include guards - end]=================================================

#endif // _TEMPSENSOR_H_
