/* libraries*/
#include "locksystem.h"
/* code */
int main(){

  locksysInit();

  while(true){

    locksysUpdate();

  }
  
}

    
